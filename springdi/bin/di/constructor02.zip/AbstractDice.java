package di.constructor02;

public interface AbstractDice {
	public int getDiceValue();
}
