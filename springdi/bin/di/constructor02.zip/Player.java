package di.constructor02;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Player implements AbstractPlayer{
	/*ApplicationContext container = 
			new ClassPathXmlApplicationContext("config/bean.xml");
	Dice d = (Dice)container.getBean("dice");*/
	
	Dice d;
	
	public Player(){
		
	}
	public Player(Dice d) {
		super();
		this.d = d;
	}
	int totalValue=0;
	public void play(){
		totalValue=0;
		for (int i = 0; i < 3; i++) {
			totalValue+=d.getDiceValue();
		}
	}
	public int getTotalValue(){
		return totalValue;
	}
}
