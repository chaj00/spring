package di.constructor02;

public interface AbstractPlayer {
	public void play();
	public int getTotalValue();
}
