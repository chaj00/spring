package mydept;

import java.util.List;

public interface AbstractUI {

	void show();

	void countMenu();

	void insertMenu();

	void updateMenu();

	void deleteMenu();
	
	void findByDeptnoMenu();
	
	void showAllMenu();
	
	void getMemberMenu();
	
	
	
}
