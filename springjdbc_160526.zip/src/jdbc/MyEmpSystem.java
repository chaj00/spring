package jdbc;


public class MyEmpSystem {
	public static void main(String[] args) {
		MenuUI ui = new MenuUI();
		while(true){
			ui.show();
		}

	}

}
